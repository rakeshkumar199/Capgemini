package com.capgemini.RabbitMQAssignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RabbitMqAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
