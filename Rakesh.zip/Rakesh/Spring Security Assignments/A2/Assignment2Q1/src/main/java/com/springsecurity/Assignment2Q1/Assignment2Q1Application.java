package com.springsecurity.Assignment2Q1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment2Q1Application {

	public static void main(String[] args) {
		SpringApplication.run(Assignment2Q1Application.class, args);
	}

}
