package com.springsecurity.Assignment2Q1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment2Q1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
