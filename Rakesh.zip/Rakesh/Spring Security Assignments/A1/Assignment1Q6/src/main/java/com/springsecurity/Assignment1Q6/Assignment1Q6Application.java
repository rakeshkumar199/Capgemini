package com.springsecurity.Assignment1Q6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment1Q6Application {

	public static void main(String[] args) {
		SpringApplication.run(Assignment1Q6Application.class, args);
	}

}
