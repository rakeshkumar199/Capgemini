package com.springsecurity.Assignment1Q2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment1Q2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
