if(1){
    let a = 10;
}

console.log(a); // output will be: cannot find name 'a'.
