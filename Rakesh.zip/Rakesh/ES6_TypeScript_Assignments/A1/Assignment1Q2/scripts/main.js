"use strict";
if (1) {
    var a = 10;
}
console.log(a); // output will be: cannot find name 'a'.
//# sourceMappingURL=main.js.map