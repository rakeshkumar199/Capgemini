"use strict";
var x = 10;
x = 20; // cannot assign to x because it is a constant.
//# sourceMappingURL=main.js.map