package com.example.demo;

public class Test {
	private int Questionid;

	public int getQuestionid() {
		return Questionid;
	}

	public void setQuestionid(int questionid) {
		this.Questionid = questionid;
	}
	

}
