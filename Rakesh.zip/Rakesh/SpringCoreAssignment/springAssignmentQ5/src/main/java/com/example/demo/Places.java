package com.example.demo;

public interface Places {

	public void visited();

}
